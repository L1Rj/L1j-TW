/* 20090605 l1j-tw l1j-tw用 與l1j更新無關 */
/* spawnlist_door 寵物競速賽 門 移動編號 */
delete from spawnlist_door where id = '5000' ;
delete from spawnlist_door where id = '5001' ;
INSERT INTO `spawnlist_door` VALUES (9000, 'race', 6677, 32762, 32848, 5143, 1, 32845, 32852, 0, 5143);
INSERT INTO `spawnlist_door` VALUES (9001, 'race', 2510, 32772, 32848, 5143, 1, 32845, 32852, 0, 5143);

