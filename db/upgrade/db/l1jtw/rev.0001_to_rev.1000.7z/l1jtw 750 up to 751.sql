/* 20090708 l1j-tw l1j-tw用 與l1j更新無關 */
/* droplist 移除龍騎士書板掉落 改用rev1944日板掉落 */
delete from droplist where itemId = '49105' ;
delete from droplist where itemId = '49106' ;
delete from droplist where itemId = '49110' ;
delete from droplist where itemId = '49111' ;
delete from droplist where itemId = '49112' ;
delete from droplist where itemId = '49114' ;
delete from droplist where itemId = '49113' ;
