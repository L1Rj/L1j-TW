/* 20100329 l1jtw spawnlist_npc 放置地圖修正 多魯嘉貝爾 屠龍佈告欄 班酷 強韌的海斯 細心的修樂 頑強的歐浩 燦爛的艾咪 米米 魔法師梅琳 */

Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91050';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91052';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91053';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91054';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91055';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91056';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91057';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91058';
Update spawnlist_npc Set mapid = '4' Where npc_templateid = '91062';
Update spawnlist_npc Set locx = '33711' Where npc_templateid = '91062';
Update spawnlist_npc Set locy = '32824' Where npc_templateid = '91062';

/* 多魯嘉貝爾  nameid 修正 */
Update npc Set nameid = '$7744' Where npcid = '91050';