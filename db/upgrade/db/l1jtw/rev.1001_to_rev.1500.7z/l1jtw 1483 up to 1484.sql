/* 20100523 l1jtw 修正熾炎天使弓攻擊力 http://gametsg.yatta.com.tw/lineage/index.php?view=item&list=no&k1=normal&item=5032 */
Update weapon Set dmg_small  = '2' Where item_id = '205';
Update weapon Set dmg_large  = '2' Where item_id = '205';