/* 20100402 l1jtw NPC Action */

/* 新增 NPC Action 強韌的海斯 細心的修樂 頑強的歐浩 燦爛的艾咪 米米 卡瑞 帕利特 伊帕奇 隱匿的巨龍谷入口 */
INSERT INTO `npcaction` VALUES ('91056', 'bankoo1', 'bankoo1', '', '');				/* 班酷 */
INSERT INTO `npcaction` VALUES ('91057', 'fivelviin1', 'fivelviin1', '', '');		/* 強韌的海斯 */
INSERT INTO `npcaction` VALUES ('91058', 'fivelviin2', 'fivelviin2', '', '');		/* 細心的修樂 */
INSERT INTO `npcaction` VALUES ('91059', 'fivelviin3', 'fivelviin3', '', '');		/* 頑強的歐浩 */
INSERT INTO `npcaction` VALUES ('91060', 'fivelviin4', 'fivelviin4', '', '');		/* 燦爛的艾咪 */
INSERT INTO `npcaction` VALUES ('91061', 'sherme2', 'sherme2', '', '');				/* 米米 */
INSERT INTO `npcaction` VALUES ('91062', 'grayknight1', 'grayknight1', '', '');		/* 卡瑞 */
INSERT INTO `npcaction` VALUES ('91063', 'familyed', 'familyedl', 'pfamilyed', '');	/* 帕利特 */
INSERT INTO `npcaction` VALUES ('91064', 'ilbakiel', 'ilbakiel', '', '');			/* 伊帕奇 */
INSERT INTO `npcaction` VALUES ('91066', 'dsecret1', 'dsecret2', 'dsecret3', '');	/* 隱匿的巨龍谷入口 */