/* 20100325 l1j-tw 將 etcitem中 max_charge_count 大於1的道具移至 itemspacially */
delete from etcitem where item_id = '40006' ;
delete from etcitem where item_id = '40007' ;
delete from etcitem where item_id = '40008' ;
delete from etcitem where item_id = '40009' ;
delete from etcitem where item_id = '41401' ;
delete from etcitem where item_id = '140006' ;
delete from etcitem where item_id = '140008' ;