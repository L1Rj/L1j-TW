/* 20091001 新增GM指令(.crazy)*/
INSERT INTO `commands` VALUES ('crazy', '200', 'L1Crazy');
INSERT INTO `commands` VALUES ('狂暴', '200', 'L1Crazy');

/* 20091016 新增GM指令(.save)*/
INSERT INTO `commands` VALUES ('save', '200', 'L1Save');
INSERT INTO `commands` VALUES ('儲存', '200', 'L1Save');