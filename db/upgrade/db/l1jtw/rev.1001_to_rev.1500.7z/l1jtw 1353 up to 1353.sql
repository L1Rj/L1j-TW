/* 20100331 l1jtw BAO提供  NPC 米米座標修正 */

Update spawnlist_npc Set locx = '33695' Where npc_templateid = '91061';