/* 20100518 l1jtw 修正魔眼延遲使用時間 */

Update etcitem Set delay_time = '3600' Where item_id = '50508';
Update etcitem Set delay_time = '3600' Where item_id = '50509';
Update etcitem Set delay_time = '3600' Where item_id = '50510';
Update etcitem Set delay_time = '3600' Where item_id = '50511';
Update etcitem Set delay_time = '3600' Where item_id = '50512';
Update etcitem Set delay_time = '3600' Where item_id = '50513';
Update etcitem Set delay_time = '3600' Where item_id = '50514';