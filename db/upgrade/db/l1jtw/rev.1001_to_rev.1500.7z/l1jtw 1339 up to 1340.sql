/* 20100329 l1jtw 防具 四龍的力量 魅惑 泉源 霸氣 多魯嘉之袋 龍之鑰匙 四龍之魔眼 誕生/形象/生命之魔眼 道具說明修正 */

/* 防具 四龍的力量 魅惑 泉源 霸氣 道具說明修正 */
Update armor Set itemdesc_id = '4016' Where item_id = '21200';
Update armor Set itemdesc_id = '4017' Where item_id = '21201';
Update armor Set itemdesc_id = '4018' Where item_id = '21202';
Update armor Set itemdesc_id = '4019' Where item_id = '21203';

Update armor Set itemdesc_id = '4020' Where item_id = '21204';
Update armor Set itemdesc_id = '4021' Where item_id = '21205';
Update armor Set itemdesc_id = '4022' Where item_id = '21206';
Update armor Set itemdesc_id = '4023' Where item_id = '21207';

Update armor Set itemdesc_id = '4028' Where item_id = '21208';
Update armor Set itemdesc_id = '4029' Where item_id = '21209';
Update armor Set itemdesc_id = '4030' Where item_id = '21210';
Update armor Set itemdesc_id = '4031' Where item_id = '21211';

Update armor Set itemdesc_id = '4024' Where item_id = '21212';
Update armor Set itemdesc_id = '4025' Where item_id = '21213';
Update armor Set itemdesc_id = '4026' Where item_id = '21214';
Update armor Set itemdesc_id = '4027' Where item_id = '21215';

/* 道具 多魯嘉之袋 龍之鑰匙 四龍之魔眼 誕生/形象/生命之魔眼 道具說明修正 */
Update etcitem Set itemdesc_id = '4046' Where item_id = '50500'; /* 多魯嘉之袋 */
Update etcitem Set itemdesc_id = '4045' Where item_id = '50501'; /* 龍之鑰匙 */
Update etcitem Set itemdesc_id = '4012' Where item_id = '50504'; /* 受封印地龍之魔眼 */
Update etcitem Set itemdesc_id = '4013' Where item_id = '50505'; /* 受封印水龍之魔眼 */
Update etcitem Set itemdesc_id = '4014' Where item_id = '50506'; /* 受封印風龍之魔眼 */
Update etcitem Set itemdesc_id = '4015' Where item_id = '50507'; /* 受封印火龍之魔眼 */
Update etcitem Set itemdesc_id = '4012' Where item_id = '50508'; /* 地龍之魔眼 */
Update etcitem Set itemdesc_id = '4013' Where item_id = '50509'; /* 水龍之魔眼 */
Update etcitem Set itemdesc_id = '4014' Where item_id = '50510'; /* 風龍之魔眼 */
Update etcitem Set itemdesc_id = '4015' Where item_id = '50511'; /* 火龍之魔眼 */
Update etcitem Set itemdesc_id = '4112' Where item_id = '50509'; /* 誕生之魔眼 */
Update etcitem Set itemdesc_id = '4113' Where item_id = '50510'; /* 形象之魔眼 */
Update etcitem Set itemdesc_id = '4114' Where item_id = '50511'; /* 生命之魔眼 */