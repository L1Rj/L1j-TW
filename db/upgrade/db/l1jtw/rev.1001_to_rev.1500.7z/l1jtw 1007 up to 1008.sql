/* 20090815 l1j-tw l1j-tw專用 與l1j更新無關 僅提供 1007 更新到1008使用 其他版本無須執行*/
/* 修正 spawnlist_npc 編號過近 */
Update spawnlist_npc Set id = '1310450' Where id = '1310415';
Update spawnlist_npc Set id = '1310451' Where id = '1310416';
Update spawnlist_npc Set id = '1310452' Where id = '1310417';
Update spawnlist_npc Set id = '1310453' Where id = '1310418';
Update spawnlist_npc Set id = '1310454' Where id = '1310419';
Update spawnlist_npc Set id = '1310455' Where id = '1310420';
Update spawnlist_npc Set id = '1310456' Where id = '1310421';
Update spawnlist_npc Set id = '1310457' Where id = '1310422';
Update spawnlist_npc Set id = '1310458' Where id = '1310423';
Update spawnlist_npc Set id = '1310459' Where id = '1310424';
Update spawnlist_npc Set id = '1310460' Where id = '1310425';
Update spawnlist_npc Set id = '1310461' Where id = '1310426';
Update spawnlist_npc Set id = '1310462' Where id = '1310427';
Update spawnlist_npc Set id = '1310463' Where id = '1310428';
Update spawnlist_npc Set id = '1310464' Where id = '1310429';
