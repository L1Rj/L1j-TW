/* 20091226 底比斯雙刀 敏捷修正為+2 */
Update weapon Set add_dex = '2' Where item_id = '265';