/* 20100507 l1jtw 更新NPC名稱 */

Update npc Set name = '道具製作 強韌的海斯' Where npcid = '91057';
Update npc Set name = '道具製作 細心的修樂' Where npcid = '91058';
Update npc Set name = '道具製作 頑強的歐浩' Where npcid = '91059';
Update npc Set name = '道具製作 燦爛的艾咪' Where npcid = '91060';