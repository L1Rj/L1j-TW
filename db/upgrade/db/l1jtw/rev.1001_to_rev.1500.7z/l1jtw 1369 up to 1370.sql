/* 20100404 l1jtw 變型新增 */

/* 變形新增槍兵資料 */
INSERT INTO `polymorphs` VALUES ('7332', 'spearm 52', '7332', '52', '1080', '2047', '1', '7');
INSERT INTO `polymorphs` VALUES ('7338', 'spearm 55', '7338', '55', '1080', '2047', '1', '7');
INSERT INTO `polymorphs` VALUES ('7339', 'spearm 60', '7339', '60', '1080', '2047', '1', '7');
INSERT INTO `polymorphs` VALUES ('7340', 'spearm 65', '7340', '65', '1080', '2047', '1', '7');
INSERT INTO `polymorphs` VALUES ('7341', 'spearm 70', '7341', '70', '1080', '2047', '1', '7');