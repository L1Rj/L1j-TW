/* 20100507 l1jtw 更新防具名稱 */

Update armor Set unidentified_name_id = '終極$5255' Where item_id = '21068';
Update armor Set identified_name_id = '終極$5255' Where item_id = '21068';
Update armor Set unidentified_name_id = '$5591' Where item_id = '21509';
Update armor Set identified_name_id = '$5591' Where item_id = '21509';
Update armor Set unidentified_name_id = '$5907' Where item_id = '21551';
Update armor Set identified_name_id = '$5907' Where item_id = '21551';