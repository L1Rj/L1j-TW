/* 20100328 l1jtw 修正四龍的 力量 魅惑 泉源 霸氣 16件防具資料 grdgfx 仍不正確 */

/* 安塔瑞斯的力量 */
Update armor Set unidentified_name_id = '$7865' Where item_id = '21200';
Update armor Set identified_name_id = '$7865' Where item_id = '21200';
Update armor Set invgfx = '3656' Where item_id = '21200';

/* 安塔瑞斯的魅惑 */
Update armor Set unidentified_name_id = '$7866' Where item_id = '21201';
Update armor Set identified_name_id = '$7866' Where item_id = '21201';
Update armor Set invgfx = '3648' Where item_id = '21201';

/* 安塔瑞斯的泉源 */
Update armor Set unidentified_name_id = '$7867' Where item_id = '21202';
Update armor Set identified_name_id = '$7867' Where item_id = '21202';
Update armor Set invgfx = '3660' Where item_id = '21202';

/* 安塔瑞斯的霸氣 */
Update armor Set unidentified_name_id = '$7868' Where item_id = '21203';
Update armor Set identified_name_id = '$7868' Where item_id = '21203';
Update armor Set invgfx = '3652' Where item_id = '21203';

/* 法利昂的力量 */
Update armor Set unidentified_name_id = '$7869' Where item_id = '21204';
Update armor Set identified_name_id = '$7869' Where item_id = '21204';
Update armor Set invgfx = '3655' Where item_id = '21204';

/* 法利昂的魅惑 */
Update armor Set unidentified_name_id = '$7870' Where item_id = '21205';
Update armor Set identified_name_id = '$7870' Where item_id = '21205';
Update armor Set invgfx = '3647' Where item_id = '21205';

/* 法利昂的泉源 */
Update armor Set unidentified_name_id = '$7871' Where item_id = '21206';
Update armor Set identified_name_id = '$7871' Where item_id = '21206';
Update armor Set invgfx = '3659' Where item_id = '21206';

/* 法利昂的霸氣 */
Update armor Set unidentified_name_id = '$7872' Where item_id = '21207';
Update armor Set identified_name_id = '$7872' Where item_id = '21207';
Update armor Set invgfx = '3651' Where item_id = '21207';

/* 林德拜爾的力量 */
Update armor Set unidentified_name_id = '$7873' Where item_id = '21208';
Update armor Set identified_name_id = '$7873' Where item_id = '21208';
Update armor Set invgfx = '3657' Where item_id = '21208';

/* 林德拜爾的魅惑 */
Update armor Set unidentified_name_id = '$7874' Where item_id = '21209';
Update armor Set identified_name_id = '$7874' Where item_id = '21209';
Update armor Set invgfx = '3649' Where item_id = '21209';

/* 林德拜爾的泉源 */
Update armor Set unidentified_name_id = '$7875' Where item_id = '21210';
Update armor Set identified_name_id = '$7875' Where item_id = '21210';
Update armor Set invgfx = '3661' Where item_id = '21210';

/* 林德拜爾的霸氣 */
Update armor Set unidentified_name_id = '$7876' Where item_id = '21211';
Update armor Set identified_name_id = '$7876' Where item_id = '21211';
Update armor Set invgfx = '3653' Where item_id = '21211';

/* 巴拉卡斯的力量 */
Update armor Set unidentified_name_id = '$7877' Where item_id = '21212';
Update armor Set identified_name_id = '$7877' Where item_id = '21212';
Update armor Set invgfx = '3658' Where item_id = '21212';

/* 巴拉卡斯的魅惑 */
Update armor Set unidentified_name_id = '$7878' Where item_id = '21213';
Update armor Set identified_name_id = '$7878' Where item_id = '21213';
Update armor Set invgfx = '3650' Where item_id = '21213';

/* 巴拉卡斯的泉源 */
Update armor Set unidentified_name_id = '$7879' Where item_id = '21214';
Update armor Set identified_name_id = '$7879' Where item_id = '21214';
Update armor Set invgfx = '3662' Where item_id = '21210';

/* 巴拉卡斯的霸氣 */
Update armor Set unidentified_name_id = '$7880' Where item_id = '21215';
Update armor Set identified_name_id = '$7880' Where item_id = '21215';
Update armor Set invgfx = '3654' Where item_id = '21215';