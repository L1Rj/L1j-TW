/* 20091119 修正龍騎士技能 屠宰者 延遲時間 */
Update skills Set reuseDelay = '600' Where skill_id = '187';