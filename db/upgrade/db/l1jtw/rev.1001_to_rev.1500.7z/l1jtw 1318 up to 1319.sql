/* 20100326 l1jtw 新增 卡拉 收購物品 */

/* 卡拉收購 褪色戒指 褪色項鍊 染血的手帕 染血的文件 */
INSERT INTO `shop` VALUES ('91007', '41113', '0', '-1', '0', '2500');
INSERT INTO `shop` VALUES ('91007', '41116', '1', '-1', '0', '10000');
INSERT INTO `shop` VALUES ('91007', '41114', '2', '-1', '0', '5000');
INSERT INTO `shop` VALUES ('91007', '41115', '3', '-1', '0', '8000');

/* 70056 二手商人 喬德 販賣道具(與 70068 歐瑞 福朗克同) */
INSERT INTO `shop` VALUES ('70056', '41', '0', '95000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '148', '1', '105600', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '142', '2', '83000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '29', '3', '88000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '129', '4', '77000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '125', '5', '84000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20125', '6', '63000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20011', '7', '58000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20036', '8', '82800', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20013', '9', '81000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20014', '10', '73000', '0', '-1');
INSERT INTO `shop` VALUES ('70056', '20015', '11', '76000', '0', '-1');