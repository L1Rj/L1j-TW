/* 20091227 魔法卷軸編號移動 */
Update etcitem Set item_id = '50001' Where item_id = '40859'; /* 魔法卷軸 (初級治癒術) */
Update etcitem Set item_id = '50002' Where item_id = '40860'; 
Update etcitem Set item_id = '50003' Where item_id = '40861'; 
Update etcitem Set item_id = '50004' Where item_id = '40862'; 
Update etcitem Set item_id = '50005' Where item_id = '40863'; /* 魔法卷軸 (指定傳送) */
Update etcitem Set item_id = '50006' Where item_id = '40864'; 
Update etcitem Set item_id = '50007' Where item_id = '40865'; 
Update etcitem Set item_id = '50008' Where item_id = '40866'; 
Update etcitem Set item_id = '50009' Where item_id = '40867'; 
Update etcitem Set item_id = '50010' Where item_id = '40868'; 
Update etcitem Set item_id = '50011' Where item_id = '40869'; 
Update etcitem Set item_id = '50012' Where item_id = '40870'; 
Update etcitem Set item_id = '50013' Where item_id = '40871'; 
Update etcitem Set item_id = '50014' Where item_id = '40872'; 
Update etcitem Set item_id = '50015' Where item_id = '40873'; 
Update etcitem Set item_id = '50016' Where item_id = '40874'; 
Update etcitem Set item_id = '50017' Where item_id = '40875'; 
Update etcitem Set item_id = '50018' Where item_id = '40876'; 
Update etcitem Set item_id = '50019' Where item_id = '40877'; 
Update etcitem Set item_id = '50020' Where item_id = '40878'; 
Update etcitem Set item_id = '50021' Where item_id = '40879'; 
Update etcitem Set item_id = '50022' Where item_id = '40880'; 
Update etcitem Set item_id = '50023' Where item_id = '40881'; 
Update etcitem Set item_id = '50025' Where item_id = '40883'; 
Update etcitem Set item_id = '50026' Where item_id = '40884'; 
Update etcitem Set item_id = '50027' Where item_id = '40885'; 
Update etcitem Set item_id = '50028' Where item_id = '40886'; 
Update etcitem Set item_id = '50029' Where item_id = '40887'; 
Update etcitem Set item_id = '50030' Where item_id = '40888'; 
Update etcitem Set item_id = '50031' Where item_id = '40889'; 
Update etcitem Set item_id = '50032' Where item_id = '40890'; 
Update etcitem Set item_id = '50033' Where item_id = '40891'; 
Update etcitem Set item_id = '50034' Where item_id = '40892'; 
Update etcitem Set item_id = '50035' Where item_id = '40893'; 
Update etcitem Set item_id = '50036' Where item_id = '40894'; 
Update etcitem Set item_id = '50037' Where item_id = '40895'; 
Update etcitem Set item_id = '50038' Where item_id = '40896'; 
Update etcitem Set item_id = '50039' Where item_id = '40897'; 
Update etcitem Set item_id = '50040' Where item_id = '40898'; 

Update etcitem Set item_id = '50042' Where item_id = '49281'; /* 魔法卷軸 (體魄強健術) */
Update etcitem Set item_id = '50048' Where item_id = '49282'; /* 魔法卷軸 (祝福魔法武器) */
Update etcitem Set item_id = '50049' Where item_id = '49283'; /* 魔法卷軸 (體力回復術) */
Update etcitem Set item_id = '50052' Where item_id = '49284'; /* 魔法卷軸 (神聖疾走) */
Update etcitem Set item_id = '50054' Where item_id = '49285'; /* 魔法卷軸 (強力加速術) */
Update etcitem Set item_id = '50057' Where item_id = '49286'; /* 魔法卷軸 (全部治癒術) */

/* 更新原有角色道具 魔法卷軸編號 */
Update character_items Set item_id = '50001' Where item_id = '40859'; /* 魔法卷軸 (初級治癒術) */
Update character_items Set item_id = '50002' Where item_id = '40860'; 
Update character_items Set item_id = '50003' Where item_id = '40861'; 
Update character_items Set item_id = '50004' Where item_id = '40862'; 
Update character_items Set item_id = '50005' Where item_id = '40863'; 
Update character_items Set item_id = '50006' Where item_id = '40864'; 
Update character_items Set item_id = '50007' Where item_id = '40865'; 
Update character_items Set item_id = '50008' Where item_id = '40866'; 
Update character_items Set item_id = '50009' Where item_id = '40867'; 
Update character_items Set item_id = '50010' Where item_id = '40868'; 
Update character_items Set item_id = '50011' Where item_id = '40869'; 
Update character_items Set item_id = '50012' Where item_id = '40870'; 
Update character_items Set item_id = '50013' Where item_id = '40871'; 
Update character_items Set item_id = '50014' Where item_id = '40872'; 
Update character_items Set item_id = '50015' Where item_id = '40873'; 
Update character_items Set item_id = '50016' Where item_id = '40874'; 
Update character_items Set item_id = '50017' Where item_id = '40875'; 
Update character_items Set item_id = '50018' Where item_id = '40876'; 
Update character_items Set item_id = '50019' Where item_id = '40877'; 
Update character_items Set item_id = '50020' Where item_id = '40878'; 
Update character_items Set item_id = '50021' Where item_id = '40879'; 
Update character_items Set item_id = '50022' Where item_id = '40880'; 
Update character_items Set item_id = '50023' Where item_id = '40881'; 
Update character_items Set item_id = '50025' Where item_id = '40883'; 
Update character_items Set item_id = '50026' Where item_id = '40884'; 
Update character_items Set item_id = '50027' Where item_id = '40885'; 
Update character_items Set item_id = '50028' Where item_id = '40886'; 
Update character_items Set item_id = '50029' Where item_id = '40887'; 
Update character_items Set item_id = '50030' Where item_id = '40888'; 
Update character_items Set item_id = '50031' Where item_id = '40889'; 
Update character_items Set item_id = '50032' Where item_id = '40890'; 
Update character_items Set item_id = '50033' Where item_id = '40891'; 
Update character_items Set item_id = '50034' Where item_id = '40892'; 
Update character_items Set item_id = '50035' Where item_id = '40893'; 
Update character_items Set item_id = '50036' Where item_id = '40894'; 
Update character_items Set item_id = '50037' Where item_id = '40895'; 
Update character_items Set item_id = '50038' Where item_id = '40896'; 
Update character_items Set item_id = '50039' Where item_id = '40897'; 
Update character_items Set item_id = '50040' Where item_id = '40898'; 

Update character_items Set item_id = '50042' Where item_id = '49281'; /* 魔法卷軸 (體魄強健術) */
Update character_items Set item_id = '50048' Where item_id = '49282'; /* 魔法卷軸 (祝福魔法武器) */
Update character_items Set item_id = '50049' Where item_id = '49283'; /* 魔法卷軸 (體力回復術) */
Update character_items Set item_id = '50052' Where item_id = '49284'; /* 魔法卷軸 (神聖疾走) */
Update character_items Set item_id = '50054' Where item_id = '49285'; /* 魔法卷軸 (強力加速術) */
Update character_items Set item_id = '50057' Where item_id = '49286'; /* 魔法卷軸 (全部治癒術) */

/* 更新原有角色倉庫 魔法卷軸編號 */
Update character_warehouse Set item_id = '50001' Where item_id = '40859'; /* 魔法卷軸 (初級治癒術) */
Update character_warehouse Set item_id = '50002' Where item_id = '40860'; 
Update character_warehouse Set item_id = '50003' Where item_id = '40861'; 
Update character_warehouse Set item_id = '50004' Where item_id = '40862'; 
Update character_warehouse Set item_id = '50005' Where item_id = '40863'; 
Update character_warehouse Set item_id = '50006' Where item_id = '40864'; 
Update character_warehouse Set item_id = '50007' Where item_id = '40865'; 
Update character_warehouse Set item_id = '50008' Where item_id = '40866'; 
Update character_warehouse Set item_id = '50009' Where item_id = '40867'; 
Update character_warehouse Set item_id = '50010' Where item_id = '40868'; 
Update character_warehouse Set item_id = '50011' Where item_id = '40869'; 
Update character_warehouse Set item_id = '50012' Where item_id = '40870'; 
Update character_warehouse Set item_id = '50013' Where item_id = '40871'; 
Update character_warehouse Set item_id = '50014' Where item_id = '40872'; 
Update character_warehouse Set item_id = '50015' Where item_id = '40873'; 
Update character_warehouse Set item_id = '50016' Where item_id = '40874'; 
Update character_warehouse Set item_id = '50017' Where item_id = '40875'; 
Update character_warehouse Set item_id = '50018' Where item_id = '40876'; 
Update character_warehouse Set item_id = '50019' Where item_id = '40877'; 
Update character_warehouse Set item_id = '50020' Where item_id = '40878'; 
Update character_warehouse Set item_id = '50021' Where item_id = '40879'; 
Update character_warehouse Set item_id = '50022' Where item_id = '40880'; 
Update character_warehouse Set item_id = '50023' Where item_id = '40881'; 
Update character_warehouse Set item_id = '50025' Where item_id = '40883'; 
Update character_warehouse Set item_id = '50026' Where item_id = '40884'; 
Update character_warehouse Set item_id = '50027' Where item_id = '40885'; 
Update character_warehouse Set item_id = '50028' Where item_id = '40886'; 
Update character_warehouse Set item_id = '50029' Where item_id = '40887'; 
Update character_warehouse Set item_id = '50030' Where item_id = '40888'; 
Update character_warehouse Set item_id = '50031' Where item_id = '40889'; 
Update character_warehouse Set item_id = '50032' Where item_id = '40890'; 
Update character_warehouse Set item_id = '50033' Where item_id = '40891'; 
Update character_warehouse Set item_id = '50034' Where item_id = '40892'; 
Update character_warehouse Set item_id = '50035' Where item_id = '40893'; 
Update character_warehouse Set item_id = '50036' Where item_id = '40894'; 
Update character_warehouse Set item_id = '50037' Where item_id = '40895'; 
Update character_warehouse Set item_id = '50038' Where item_id = '40896'; 
Update character_warehouse Set item_id = '50039' Where item_id = '40897'; 
Update character_warehouse Set item_id = '50040' Where item_id = '40898'; 

Update character_warehouse Set item_id = '50042' Where item_id = '49281'; /* 魔法卷軸 (體魄強健術) */
Update character_warehouse Set item_id = '50048' Where item_id = '49282'; /* 魔法卷軸 (祝福魔法武器) */
Update character_warehouse Set item_id = '50049' Where item_id = '49283'; /* 魔法卷軸 (體力回復術) */
Update character_warehouse Set item_id = '50052' Where item_id = '49284'; /* 魔法卷軸 (神聖疾走) */
Update character_warehouse Set item_id = '50054' Where item_id = '49285'; /* 魔法卷軸 (強力加速術) */
Update character_warehouse Set item_id = '50057' Where item_id = '49286'; /* 魔法卷軸 (全部治癒術) */

/* 更新原有角色妖精倉庫 魔法卷軸編號 */
Update character_elf_warehouse Set item_id = '50001' Where item_id = '40859'; /* 魔法卷軸 (初級治癒術) */
Update character_elf_warehouse Set item_id = '50002' Where item_id = '40860'; 
Update character_elf_warehouse Set item_id = '50003' Where item_id = '40861'; 
Update character_elf_warehouse Set item_id = '50004' Where item_id = '40862'; 
Update character_elf_warehouse Set item_id = '50005' Where item_id = '40863'; 
Update character_elf_warehouse Set item_id = '50006' Where item_id = '40864'; 
Update character_elf_warehouse Set item_id = '50007' Where item_id = '40865'; 
Update character_elf_warehouse Set item_id = '50008' Where item_id = '40866'; 
Update character_elf_warehouse Set item_id = '50009' Where item_id = '40867'; 
Update character_elf_warehouse Set item_id = '50010' Where item_id = '40868'; 
Update character_elf_warehouse Set item_id = '50011' Where item_id = '40869'; 
Update character_elf_warehouse Set item_id = '50012' Where item_id = '40870'; 
Update character_elf_warehouse Set item_id = '50013' Where item_id = '40871'; 
Update character_elf_warehouse Set item_id = '50014' Where item_id = '40872'; 
Update character_elf_warehouse Set item_id = '50015' Where item_id = '40873'; 
Update character_elf_warehouse Set item_id = '50016' Where item_id = '40874'; 
Update character_elf_warehouse Set item_id = '50017' Where item_id = '40875'; 
Update character_elf_warehouse Set item_id = '50018' Where item_id = '40876'; 
Update character_elf_warehouse Set item_id = '50019' Where item_id = '40877'; 
Update character_elf_warehouse Set item_id = '50020' Where item_id = '40878'; 
Update character_elf_warehouse Set item_id = '50021' Where item_id = '40879'; 
Update character_elf_warehouse Set item_id = '50022' Where item_id = '40880'; 
Update character_elf_warehouse Set item_id = '50023' Where item_id = '40881'; 
Update character_elf_warehouse Set item_id = '50025' Where item_id = '40883'; 
Update character_elf_warehouse Set item_id = '50026' Where item_id = '40884'; 
Update character_elf_warehouse Set item_id = '50027' Where item_id = '40885'; 
Update character_elf_warehouse Set item_id = '50028' Where item_id = '40886'; 
Update character_elf_warehouse Set item_id = '50029' Where item_id = '40887'; 
Update character_elf_warehouse Set item_id = '50030' Where item_id = '40888'; 
Update character_elf_warehouse Set item_id = '50031' Where item_id = '40889'; 
Update character_elf_warehouse Set item_id = '50032' Where item_id = '40890'; 
Update character_elf_warehouse Set item_id = '50033' Where item_id = '40891'; 
Update character_elf_warehouse Set item_id = '50034' Where item_id = '40892'; 
Update character_elf_warehouse Set item_id = '50035' Where item_id = '40893'; 
Update character_elf_warehouse Set item_id = '50036' Where item_id = '40894'; 
Update character_elf_warehouse Set item_id = '50037' Where item_id = '40895'; 
Update character_elf_warehouse Set item_id = '50038' Where item_id = '40896'; 
Update character_elf_warehouse Set item_id = '50039' Where item_id = '40897'; 
Update character_elf_warehouse Set item_id = '50040' Where item_id = '40898'; 

Update character_elf_warehouse Set item_id = '50042' Where item_id = '49281'; /* 魔法卷軸 (體魄強健術) */
Update character_elf_warehouse Set item_id = '50048' Where item_id = '49282'; /* 魔法卷軸 (祝福魔法武器) */
Update character_elf_warehouse Set item_id = '50049' Where item_id = '49283'; /* 魔法卷軸 (體力回復術) */
Update character_elf_warehouse Set item_id = '50052' Where item_id = '49284'; /* 魔法卷軸 (神聖疾走) */
Update character_elf_warehouse Set item_id = '50054' Where item_id = '49285'; /* 魔法卷軸 (強力加速術) */
Update character_elf_warehouse Set item_id = '50057' Where item_id = '49286'; /* 魔法卷軸 (全部治癒術) */

/* 更新原有角色血盟倉庫 魔法卷軸編號 */
Update clan_warehouse Set item_id = '50001' Where item_id = '40859'; /* 魔法卷軸 (初級治癒術) */
Update clan_warehouse Set item_id = '50002' Where item_id = '40860'; 
Update clan_warehouse Set item_id = '50003' Where item_id = '40861'; 
Update clan_warehouse Set item_id = '50004' Where item_id = '40862'; 
Update clan_warehouse Set item_id = '50005' Where item_id = '40863'; 
Update clan_warehouse Set item_id = '50006' Where item_id = '40864'; 
Update clan_warehouse Set item_id = '50007' Where item_id = '40865'; 
Update clan_warehouse Set item_id = '50008' Where item_id = '40866'; 
Update clan_warehouse Set item_id = '50009' Where item_id = '40867'; 
Update clan_warehouse Set item_id = '50010' Where item_id = '40868'; 
Update clan_warehouse Set item_id = '50011' Where item_id = '40869'; 
Update clan_warehouse Set item_id = '50012' Where item_id = '40870'; 
Update clan_warehouse Set item_id = '50013' Where item_id = '40871'; 
Update clan_warehouse Set item_id = '50014' Where item_id = '40872'; 
Update clan_warehouse Set item_id = '50015' Where item_id = '40873'; 
Update clan_warehouse Set item_id = '50016' Where item_id = '40874'; 
Update clan_warehouse Set item_id = '50017' Where item_id = '40875'; 
Update clan_warehouse Set item_id = '50018' Where item_id = '40876'; 
Update clan_warehouse Set item_id = '50019' Where item_id = '40877'; 
Update clan_warehouse Set item_id = '50020' Where item_id = '40878'; 
Update clan_warehouse Set item_id = '50021' Where item_id = '40879'; 
Update clan_warehouse Set item_id = '50022' Where item_id = '40880'; 
Update clan_warehouse Set item_id = '50023' Where item_id = '40881'; 
Update clan_warehouse Set item_id = '50025' Where item_id = '40883'; 
Update clan_warehouse Set item_id = '50026' Where item_id = '40884'; 
Update clan_warehouse Set item_id = '50027' Where item_id = '40885'; 
Update clan_warehouse Set item_id = '50028' Where item_id = '40886'; 
Update clan_warehouse Set item_id = '50029' Where item_id = '40887'; 
Update clan_warehouse Set item_id = '50030' Where item_id = '40888'; 
Update clan_warehouse Set item_id = '50031' Where item_id = '40889'; 
Update clan_warehouse Set item_id = '50032' Where item_id = '40890'; 
Update clan_warehouse Set item_id = '50033' Where item_id = '40891'; 
Update clan_warehouse Set item_id = '50034' Where item_id = '40892'; 
Update clan_warehouse Set item_id = '50035' Where item_id = '40893'; 
Update clan_warehouse Set item_id = '50036' Where item_id = '40894'; 
Update clan_warehouse Set item_id = '50037' Where item_id = '40895'; 
Update clan_warehouse Set item_id = '50038' Where item_id = '40896'; 
Update clan_warehouse Set item_id = '50039' Where item_id = '40897'; 
Update clan_warehouse Set item_id = '50040' Where item_id = '40898'; 

Update clan_warehouse Set item_id = '50042' Where item_id = '49281'; /* 魔法卷軸 (體魄強健術) */
Update clan_warehouse Set item_id = '50048' Where item_id = '49282'; /* 魔法卷軸 (祝福魔法武器) */
Update clan_warehouse Set item_id = '50049' Where item_id = '49283'; /* 魔法卷軸 (體力回復術) */
Update clan_warehouse Set item_id = '50052' Where item_id = '49284'; /* 魔法卷軸 (神聖疾走) */
Update clan_warehouse Set item_id = '50054' Where item_id = '49285'; /* 魔法卷軸 (強力加速術) */
Update clan_warehouse Set item_id = '50057' Where item_id = '49286'; /* 魔法卷軸 (全部治癒術) */