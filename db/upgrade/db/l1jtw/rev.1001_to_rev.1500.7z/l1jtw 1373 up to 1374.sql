/* 20100404 l1jtw NPC&道具地面外觀修正 */

/* 奇岩地監傳送師梅琳 gfxid */
Update npc Set gfxid = '2400' Where item_id = '50500';

/* 4龍的力量 魅惑 霸氣 泉源 grdfx */
Update armor Set grdgfx = '7668' Where item_id = '21200';
Update armor Set grdgfx = '7666' Where item_id = '21201';
Update armor Set grdgfx = '7669' Where item_id = '21202';
Update armor Set grdgfx = '7667' Where item_id = '21203';
Update armor Set grdgfx = '7668' Where item_id = '21204';
Update armor Set grdgfx = '7666' Where item_id = '21205';
Update armor Set grdgfx = '7669' Where item_id = '21206';
Update armor Set grdgfx = '7667' Where item_id = '21207';
Update armor Set grdgfx = '7668' Where item_id = '21208';
Update armor Set grdgfx = '7666' Where item_id = '21209';
Update armor Set grdgfx = '7669' Where item_id = '21210';
Update armor Set grdgfx = '7667' Where item_id = '21211';
Update armor Set grdgfx = '7668' Where item_id = '21212';
Update armor Set grdgfx = '7666' Where item_id = '21213';
Update armor Set grdgfx = '7669' Where item_id = '21214';
Update armor Set grdgfx = '7667' Where item_id = '21215';

/* 幼龍蛋 grdfx */
Update etcitem Set grdgfx = '7670' Where item_id = '50502';
Update etcitem Set grdgfx = '7670' Where item_id = '50503';