/* 20100329 l1jtw NPC 91050 91051 action */
INSERT INTO `npcaction` VALUES ('91050', 'veil1', 'veil1', '', '');
INSERT INTO `npcaction` VALUES ('91051', 'dragonsmap', 'dragonsmap', '', '');