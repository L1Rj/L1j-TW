/* 20100513 修正亞丁大陸座標錯誤 */
Update mapids Set startX = '32384' Where mapid = '4';
