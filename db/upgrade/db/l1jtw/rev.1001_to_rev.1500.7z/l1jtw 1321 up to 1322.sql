/* 20100326 l1jtw itemspacially 欄位名稱變更 */

ALTER TABLE itemspacially CHANGE survive_time max_use_time int(10) unsigned NOT NULL DEFAULT '0';