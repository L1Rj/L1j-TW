/* 20100504 l1jtw 新增GM指令 System 系統 用於顯示系統資訊 */

INSERT INTO `commands` VALUES ('system', '200', 'L1System');
INSERT INTO `commands` VALUES ('系統', '200', 'L1System');