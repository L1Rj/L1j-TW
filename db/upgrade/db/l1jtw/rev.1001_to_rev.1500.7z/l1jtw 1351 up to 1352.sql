/* 20100331 l1jtw BAO提供  NPC gfxid 多魯嘉貝爾7618  海斯2255  修樂1621 歐浩782 艾咪6239 卡瑞1049 */

Update npc Set gfxid = '7618' Where npcid = '91050';
Update npc Set gfxid = '2255' Where npcid = '91057';
Update npc Set gfxid = '1621' Where npcid = '91058';
Update npc Set gfxid = '782' Where npcid = '91059';
Update npc Set gfxid = '6239' Where npcid = '91060';
Update npc Set gfxid = '1049' Where npcid = '91062';
