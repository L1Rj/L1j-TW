/* 20100517 l1jtw 更新NPC名稱 */

Update spawnlist_npc Set location = '道具製作 強韌的海斯', mapid = '4', heading = '7' Where id = '1310446';
Update spawnlist_npc Set location = '道具製作 細心的修樂', mapid = '4', heading = '2' Where id = '1310447';
Update spawnlist_npc Set location = '道具製作 頑強的歐浩', mapid = '4', heading = '6' Where id = '1310448';
Update spawnlist_npc Set location = '道具製作 燦爛的艾咪', mapid = '4', heading = '2' Where id = '1310449';