/* 20100513 修正錯誤名字，更改為異界 奎斯特+座標錯誤修正 */
Update mapids Set locationname = '異界 奎斯特', endY = '32895' Where mapid = '2004';
