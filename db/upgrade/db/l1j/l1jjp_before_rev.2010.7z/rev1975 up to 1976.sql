/* 20090804 npc 修正資料 */
Update npc Set passispeed = '1440' ,atkspeed = '880' ,alt_atk_speed = '880' Where npcid = '45384';
Update npc Set passispeed = '1440' ,atkspeed = '880' ,alt_atk_speed = '880' Where npcid = '45555';