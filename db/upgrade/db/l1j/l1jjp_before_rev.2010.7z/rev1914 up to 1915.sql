/* 20090629 spawnlist 刪除資料*/
delete from spawnlist where id = '30300001';
delete from spawnlist where id = '30300002';
delete from spawnlist where id = '30300003';

