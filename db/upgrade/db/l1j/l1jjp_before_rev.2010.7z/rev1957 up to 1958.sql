/* 20090723 npc 修正 */

Update npc Set family  = '' Where npcid  = '45890';
Update npc Set passispeed = '640' Where npcid  = '45891';
Update npc Set atkspeed  = '1280' Where npcid  = '45891';
Update npc Set family  = '' Where npcid  = '45891';
Update npc Set passispeed = '1040' Where npcid  = '45893';
Update npc Set atkspeed = '960' Where npcid  = '45893';
Update npc Set agrofamily = '0' Where npcid  = '45895';
Update npc Set agrofamily = '0' Where npcid  = '45901';
Update npc Set agrofamily = '0' Where npcid  = '45902';
Update npc Set passispeed = '960' Where npcid  = '45909';
Update npc Set atkspeed  = '1120' Where npcid  = '45909';