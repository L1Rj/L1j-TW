/* 20090608 etcitem 變更資料 */
Update etcitem Set stackable  = '1' Where item_id  = '41352';/* 任務道具 神聖獨角獸之角 改為可堆疊 */