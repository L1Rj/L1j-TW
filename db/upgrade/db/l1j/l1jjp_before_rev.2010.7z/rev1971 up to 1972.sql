/* 20090803 etcitem 新增資料表 */
alter table etcitem add `can_seal` int(2) unsigned NOT NULL default '0' after cant_delete ;