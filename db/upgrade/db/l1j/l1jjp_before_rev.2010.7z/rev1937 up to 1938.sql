/* 20090707 weapon 修正資料 */
Update weapon Set double_dmg_chance  = '30' Where item_id = '265';