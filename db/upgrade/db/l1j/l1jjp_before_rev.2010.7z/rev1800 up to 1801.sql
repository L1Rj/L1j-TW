delete from skills where skill_id = 218 ;
insert into skills values
(218, 'ジョイ オブ ペイン', 28, 1, 40, 0, 0, 0, 0, 2, 'buff', 3, 0, 0, 0, 0, 0, 0, 4, 0, 3, 0, 0, 2, '$5952', 19, 6528, 0, 0, 0, 0);
/* 不用中文化的話下面可以不用執行  */
Update skills Set name = '疼痛的歡愉' Where skill_id = '218';