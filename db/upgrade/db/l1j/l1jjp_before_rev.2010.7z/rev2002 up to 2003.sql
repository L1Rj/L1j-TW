/* 20090820 npc 修正資料 */
Update npc Set note = '黒魔法研究室、精霊召喚室' Where npcid = '45459';
Update npc Set note = '黒魔法研究室、精霊召喚室' Where npcid = '45460';
Update npc Set note = '黒魔法研究室、精霊召喚室' Where npcid = '45461';
Update npc Set note = '黒魔法研究室、精霊召喚室' Where npcid = '45462';
Update npc Set note = '黒魔法訓練場、精霊召喚室、闇の精霊研究室' Where npcid = '45465';
Update npc Set note = '精霊の生息地' Where npcid = '45854';
Update npc Set note = '精霊の生息地' Where npcid = '45855';
Update npc Set note = '精霊の生息地' Where npcid = '45856';
Update npc Set note = '精霊の生息地' Where npcid = '45857';
Update npc Set note = '闇の精霊研究室、魔霊軍王の書斎' Where npcid = '45858';
