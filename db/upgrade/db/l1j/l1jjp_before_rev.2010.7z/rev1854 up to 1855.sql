/* 20090610 rev1855 npc 變更資料 */
Update npc Set cant_resurrect  = '0' Where npcid  = '45313';
Update npc Set cant_resurrect  = '0' Where npcid  = '45711';
