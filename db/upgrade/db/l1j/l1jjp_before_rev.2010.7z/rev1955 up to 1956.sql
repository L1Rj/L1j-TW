/* 20090723 mapids 修正 */
Update mapids Set teleportable = '0' Where mapid  = '307';
Update mapids Set teleportable = '0' Where mapid  = '308';
Update mapids Set teleportable = '0' Where mapid  = '309';