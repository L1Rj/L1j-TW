/* 20090626 spawnlist 變更資料  修正傲慢 92 93 94 95樓刷怪*/
Update spawnlist Set count  = '0' Where id  = '19200001';
Update spawnlist Set count  = '0' Where id  = '19200005';
Update spawnlist Set count  = '0' Where id  = '19300002';
Update spawnlist Set count  = '0' Where id  = '19300006';
Update spawnlist Set count  = '0' Where id  = '19400001';
Update spawnlist Set count  = '0' Where id  = '19400002';
Update spawnlist Set count  = '0' Where id  = '19400004';
Update spawnlist Set count  = '0' Where id  = '19500001';
