/* 20090626 polymorphs 修正資料*/

Update polymorphs Set armorequip = '4095' Where armorequip= '2047';