/* 20090601 rev1835 shop 變更資料 */
Update shop Set item_id = '20160' Where npc_id = '81017' AND item_id = '20168';