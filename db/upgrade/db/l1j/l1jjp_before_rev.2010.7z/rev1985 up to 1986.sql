/* 20090813 spawnlist_npc 修正資料 */
Update spawnlist_npc Set locx = '33589' ,locy = '33194' ,movement_distance ='15' Where id = '89050';
Update spawnlist_npc Set locy = '33194' ,movement_distance ='15' Where id = '89051';
Update spawnlist_npc Set locx = '33657' ,locy = '33221' ,movement_distance ='15' Where id = '89052';
Update spawnlist_npc Set locx = '33657' Where id = '89053';
Update spawnlist_npc Set locx = '33618' ,locy = '33321' ,movement_distance ='15' Where id = '89054';
Update spawnlist_npc Set locx = '33618' ,movement_distance ='15' Where id = '89055';
Update spawnlist_npc Set locx = '33644' ,locy = '33429' ,movement_distance ='15' Where id = '89056';
Update spawnlist_npc Set locx = '33653' ,locy = '33427' ,movement_distance ='15' Where id = '89057';
Update spawnlist_npc Set locx = '33607' ,locy = '33449' ,heading = '5' ,movement_distance ='15' Where id = '89058';
Update spawnlist_npc Set locx = '33602' ,locy = '33445' ,heading = '5' ,movement_distance ='15' Where id = '89059';
