/* 20090531 rev1835 etcitem 新增資料 */
INSERT INTO `etcitem` VALUES
(41428, '太古の玉爾', '$6347', 'other', 'normal', 'dragonscale', 0, 3277, 7068, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 2, 1000, 0, 0, 1);