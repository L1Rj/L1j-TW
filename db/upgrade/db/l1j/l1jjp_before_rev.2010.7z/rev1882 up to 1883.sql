/* 20090619 rev1883 修正 skills 資料 */
Update skills Set type = '2' Where skill_id = '206';
Update skills Set type = '2' Where skill_id = '211';