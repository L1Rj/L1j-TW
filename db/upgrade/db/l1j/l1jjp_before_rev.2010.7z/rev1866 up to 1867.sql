/* 20090616 rev1867  修改部份NPC資料 */
Update npc Set atkspeed  = '1280' Where npcid  = '45796';
Update npc Set passispeed  = '960' Where npcid  = '45797';
Update npc Set passispeed  = '1080' Where npcid  = '45799';
Update npc Set atkspeed  = '1320' Where npcid  = '45799';
Update npc Set passispeed  = '960' Where npcid  = '45800';
Update npc Set atkspeed  = '920' Where npcid  = '45800';
Update npc Set passispeed  = '1040' Where npcid  = '45802';