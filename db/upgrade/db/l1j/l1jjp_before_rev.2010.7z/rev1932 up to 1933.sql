/* 20090706 npcchat 修正資料*/
Update npcchat Set is_shout = '0' Where npc_id = '45545' And chat_timing = '1';
Update npcchat Set is_shout = '0' Where npc_id = '45600' And chat_timing = '1';
Update npcchat Set is_shout = '0' Where npc_id = '45931' And chat_timing = '1';
Update npcchat Set is_shout = '0' Where npc_id = '45935' And chat_timing = '0';
Update npcchat Set is_shout = '0' Where npc_id = '45943' And chat_timing = '1';

