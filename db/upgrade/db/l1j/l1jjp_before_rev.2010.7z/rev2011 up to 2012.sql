/* 20090825 spawnlist 修改資料 */

Update spawnlist Set count = '0' Where id = '8200001';
Update spawnlist Set count = '0' Where id = '8200003';
Update spawnlist Set count = '0' Where id = '8200004';