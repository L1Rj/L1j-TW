/* 20090724 etcitem 修正 */
Update etcitem Set stackable = '1' Where item_id  = '49143';

INSERT INTO `etcitem` VALUES
(49278, '勇者のパンプキン袋', '$5287', '$5287', 'treasure_box', 'normal', 'vegetation', 14000, 943, 3963, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1),
(49279, '勇者のパンプキン袋', '$5287', '$5287', 'treasure_box', 'normal', 'vegetation', 14000, 943, 3963, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1),
(49280, '勇者のパンプキン袋', '$5287', '$5287', 'treasure_box', 'normal', 'vegetation', 14000, 943, 3963, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1);