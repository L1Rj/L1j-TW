/* 20090708 mapids 修正資料 */
Update mapids Set teleportable  = '1' Where mapid = '480';
