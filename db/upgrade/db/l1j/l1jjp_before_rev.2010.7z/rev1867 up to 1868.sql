/* 20090616 rev1868  修正變身錯誤 */
Update polymorphs  Set name  = 'quest' Where id  = '6035';
