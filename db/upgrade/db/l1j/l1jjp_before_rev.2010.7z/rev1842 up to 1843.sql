/* 20090604 rev1842 NPC 變更資料 */
Update npc Set IsTU = '1' Where npcid = '46091';
Update npc Set IsTU = '1' Where npcid = '46092';
Update npc Set IsTU = '1' Where npcid = '46093';
Update npc Set IsTU = '1' Where npcid = '46094';
Update npc Set IsTU = '1' Where npcid = '46095';
Update npc Set IsTU = '1' Where npcid = '46096';
Update npc Set IsTU = '1' Where npcid = '46097';
Update npc Set IsTU = '1' Where npcid = '46098';
Update npc Set IsTU = '1' Where npcid = '46099';
Update npc Set IsTU = '1' Where npcid = '46106';