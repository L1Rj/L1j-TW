/* 20090626 mobskill 修正資料*/
delete from mobskill where mobid = '45368' And actNo ='0';
delete from mobskill where mobid = '45368' And actNo ='1';
insert  into mobskill values
(45368, 0, 'ビーストサマナー(物理攻撃)', 1, 50, 0, 0, -2, 0, 0, 2, 0, 0, 2, 0, 0, 30, 0, 0, 0, 0);
