/* 20090615 rev1864  mobgroup 修改美人魚家族 */
Update mobgroup Set minion1_count  = '1' Where id  = '12';
Update mobgroup Set minion1_id  = '45940' Where id  = '12';
Update mobgroup Set note  = 'マーメイド+呪われたマーマン' Where id  = '12';