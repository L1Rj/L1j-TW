/* 20090618 rev1879  修正 droplist 掉落金幣資料 */
delete from droplist where mobId = '45006' And itemId = '40308' ;
delete from droplist where mobId = '45025' And itemId = '40308' ;
delete from droplist where mobId = '45029' And itemId = '40308' ;
delete from droplist where mobId = '45030' And itemId = '40308' ;
delete from droplist where mobId = '45068' And itemId = '40308' ;
delete from droplist where mobId = '45077' And itemId = '40308' ;
delete from droplist where mobId = '45103' And itemId = '40308' ;
delete from droplist where mobId = '45199' And itemId = '40308' ;