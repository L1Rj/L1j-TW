/* 20090706 npc 修正資料 */
Update npc Set gfxid = '4542' Where npcid = '45313';