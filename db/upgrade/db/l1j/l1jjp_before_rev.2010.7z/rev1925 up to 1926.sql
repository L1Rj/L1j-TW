/* 20090702 etcitem 修正資料*/
Update etcitem Set item_type  = 'treasure_box' Where item_id = '41097';
Update etcitem Set item_type  = 'treasure_box' Where item_id = '41102';

