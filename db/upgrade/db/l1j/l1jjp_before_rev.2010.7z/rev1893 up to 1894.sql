/* 20090623 rev1894 修正四屬性卷軸資料 */
Update etcitem Set invgfx = '3030' Where item_id = '41429';
Update etcitem Set invgfx = '3028' Where item_id = '41430';
Update etcitem Set invgfx = '3029' Where item_id = '41431';
Update etcitem Set invgfx = '3032' Where item_id = '41432';
Update etcitem Set grdgfx = '6936' Where item_id = '41429';
Update etcitem Set grdgfx = '6933' Where item_id = '41430';
Update etcitem Set grdgfx = '6935' Where item_id = '41431';
Update etcitem Set grdgfx = '6938' Where item_id = '41432';