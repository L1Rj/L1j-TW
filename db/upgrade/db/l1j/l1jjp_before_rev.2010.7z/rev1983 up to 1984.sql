/* 20090810 spawnlist_npc 修正資料 */
Update spawnlist_npc Set locx = '32741' ,locy = '32814' Where id = '87198';