/* 20090806 npc 修正資料 */
Update npc Set change_head = '0' Where npcid = '70872';

/* 20090806 spawnlist_npc 修正資料 */
Update spawnlist_npc Set locx = '32714' ,locy = '31814' Where id = '87198';
