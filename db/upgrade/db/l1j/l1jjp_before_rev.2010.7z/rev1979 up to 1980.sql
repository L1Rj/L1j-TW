/* 20090806 area 修正資料 */
Update area Set areaname = 'Tikal Temple' Where areaid = '783';
Update area Set areaname = 'Kukulcan altar' Where areaid = '784';

/* 20090806 mapids 修正資料 */
Update mapids Set locationname = 'Tikal Temple' Where mapid = '783';
Update mapids Set locationname = 'Kukulcan altar' Where mapid = '784';
