/* 20090725 npc 修正 */

Update npc Set gfxid = '4744' Where npcid  = '45518';/* 重裝歐姆戰士 ラス2F */
Update npc Set passispeed = '960' Where npcid  = '45518';
Update npc Set atkspeed = '1040' Where npcid  = '45518';
Update npc Set gfxid = '4744' Where npcid  = '45872';/* 重裝歐姆戰士 ラス3F */
Update npc Set passispeed = '960' Where npcid  = '45872';
Update npc Set atkspeed = '1040' Where npcid  = '45872';