/* 20090714 npc 修正資料 */
Update npc Set passispeed = '480' Where npcid  = '45196';
Update npc Set atkspeed = '1160' Where npcid  = '45196';
Update npc Set atk_magic_speed  = '1160' Where npcid  = '45196';
Update npc Set sub_magic_speed = '1160' Where npcid  = '45196';

Update npc Set passispeed = '420' Where npcid  = '45355';
Update npc Set atkspeed = '740' Where npcid  = '45355';
Update npc Set atk_magic_speed  = '740' Where npcid  = '45355';
Update npc Set sub_magic_speed = '740' Where npcid  = '45355';

Update npc Set passispeed = '320' Where npcid  = '45358';
Update npc Set atkspeed = '740' Where npcid  = '45358';
Update npc Set atk_magic_speed  = '740' Where npcid  = '45358';
Update npc Set sub_magic_speed = '740' Where npcid  = '45358';

Update npc Set passispeed = '440' Where npcid  = '45362';
Update npc Set atkspeed = '760' Where npcid  = '45362';
Update npc Set atk_magic_speed  = '840' Where npcid  = '45362';
Update npc Set sub_magic_speed = '840' Where npcid  = '45362';

Update npc Set passispeed = '470' Where npcid  = '45364';
Update npc Set atkspeed = '1440' Where npcid  = '45364';
Update npc Set atk_magic_speed  = '1520' Where npcid  = '45364';
Update npc Set sub_magic_speed = '1520' Where npcid  = '45364';

Update npc Set passispeed = '650' Where npcid  = '45371';
Update npc Set atkspeed = '840' Where npcid  = '45371';
Update npc Set atk_magic_speed  = '840' Where npcid  = '45371';
Update npc Set sub_magic_speed = '840' Where npcid  = '45371';

Update npc Set passispeed = '480' Where npcid  = '45377';
Update npc Set atkspeed = '680' Where npcid  = '45377';
Update npc Set atk_magic_speed  = '680' Where npcid  = '45377';
Update npc Set sub_magic_speed = '680' Where npcid  = '45377';

Update npc Set passispeed = '680' Where npcid  = '45378';
Update npc Set atkspeed = '540' Where npcid  = '45378';
Update npc Set atk_magic_speed  = '540' Where npcid  = '45378';
Update npc Set sub_magic_speed = '540' Where npcid  = '45378';

Update npc Set passispeed = '630' Where npcid  = '45387';
Update npc Set atkspeed = '1380' Where npcid  = '45387';
Update npc Set atk_magic_speed  = '1380' Where npcid  = '45387';
Update npc Set sub_magic_speed = '1380' Where npcid  = '45387';

Update npc Set passispeed = '420' Where npcid  = '45389';
Update npc Set atkspeed = '680' Where npcid  = '45389';
Update npc Set atk_magic_speed  = '680' Where npcid  = '45389';
Update npc Set sub_magic_speed = '680' Where npcid  = '45389';

Update npc Set passispeed = '480' Where npcid  = '45390';
Update npc Set atkspeed = '860' Where npcid  = '45390';
Update npc Set atk_magic_speed  = '860' Where npcid  = '45390';
Update npc Set sub_magic_speed = '860' Where npcid  = '45390';

Update npc Set passispeed = '480' Where npcid  = '45392';
Update npc Set atkspeed = '700' Where npcid  = '45392';
Update npc Set atk_magic_speed  = '700' Where npcid  = '45392';
Update npc Set sub_magic_speed = '700' Where npcid  = '45392';

Update npc Set passispeed = '320' Where npcid  = '45401';
Update npc Set atkspeed = '740' Where npcid  = '45401';
Update npc Set atk_magic_speed  = '740' Where npcid  = '45401';
Update npc Set sub_magic_speed = '740' Where npcid  = '45401';

Update npc Set passispeed = '480' Where npcid  = '45445';
Update npc Set atkspeed = '920' Where npcid  = '45445';
Update npc Set atk_magic_speed  = '920' Where npcid  = '45445';
Update npc Set sub_magic_speed = '920' Where npcid  = '45445';

Update npc Set passispeed = '480' Where npcid  = '45449';
Update npc Set atkspeed = '860' Where npcid  = '45449';
Update npc Set atk_magic_speed  = '860' Where npcid  = '45449';
Update npc Set sub_magic_speed = '860' Where npcid  = '45449';

Update npc Set passispeed = '640' Where npcid  = '45452';
Update npc Set atkspeed = '960' Where npcid  = '45452';
Update npc Set atk_magic_speed  = '1080' Where npcid  = '45452';
Update npc Set sub_magic_speed = '1080' Where npcid  = '45452';

Update npc Set passispeed = '640' Where npcid  = '45469';
Update npc Set atkspeed = '1180' Where npcid  = '45469';
Update npc Set atk_magic_speed  = '1180' Where npcid  = '45469';
Update npc Set sub_magic_speed = '1180' Where npcid  = '45469';

Update npc Set passispeed = '680' Where npcid  = '45470';
Update npc Set atkspeed = '540' Where npcid  = '45470';
Update npc Set atk_magic_speed  = '540' Where npcid  = '45470';
Update npc Set sub_magic_speed = '540' Where npcid  = '45470';

Update npc Set passispeed = '620' Where npcid  = '45477';
Update npc Set atkspeed = '960' Where npcid  = '45477';
Update npc Set atk_magic_speed  = '960' Where npcid  = '45477';
Update npc Set sub_magic_speed = '960' Where npcid  = '45477';

Update npc Set passispeed = '440' Where npcid  = '45505';
Update npc Set atkspeed = '760' Where npcid  = '45505';
Update npc Set atk_magic_speed  = '1080' Where npcid  = '45505';
Update npc Set sub_magic_speed = '1080' Where npcid  = '45505';

Update npc Set passispeed = '480' Where npcid  = '45509';
Update npc Set atkspeed = '640' Where npcid  = '45509';
Update npc Set atk_magic_speed  = '640' Where npcid  = '45509';
Update npc Set sub_magic_speed = '640' Where npcid  = '45509';

Update npc Set passispeed = '620' Where npcid  = '45531';
Update npc Set atkspeed = '860' Where npcid  = '45531';
Update npc Set atk_magic_speed  = '1180' Where npcid  = '45531';
Update npc Set sub_magic_speed = '1180' Where npcid  = '45531';

Update npc Set passispeed = '640' Where npcid  = '45538';
Update npc Set atkspeed = '780' Where npcid  = '45538';
Update npc Set atk_magic_speed  = '780' Where npcid  = '45538';
Update npc Set sub_magic_speed = '780' Where npcid  = '45538';

Update npc Set passispeed = '280' Where npcid  = '45578';
Update npc Set atkspeed = '640' Where npcid  = '45578';