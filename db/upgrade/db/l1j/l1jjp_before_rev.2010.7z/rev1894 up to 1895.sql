/* 20090623 rev1895 修正GM商店資料 */
Update shop Set item_id = '41429' Where npc_id = '81028' And item_id = '49144';
Update shop Set item_id = '41430' Where npc_id = '81028' And item_id = '49145';
Update shop Set item_id = '41431' Where npc_id = '81028' And item_id = '49146';
Update shop Set item_id = '41432' Where npc_id = '81028' And item_id = '49147';