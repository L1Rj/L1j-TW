/* 20090618 rev1875  修改 船舶之墓殭屍 資料 */
Update mobskill Set TriRnd = '50' Where mobid  = '45720';
Update npc Set ranged = '2' Where npcid  = '45720';
Update skills Set castgfx = '2510' Where skill_id = '10072';
Update skills Set damage_value = '10' Where skill_id = '10073';
Update skills Set castgfx = '5415' Where skill_id = '10073';