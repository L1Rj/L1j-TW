/* 20090601 rev1840 skill 變更資料 */
Update skills Set buffDuration = '1800' Where skill_id = '79';