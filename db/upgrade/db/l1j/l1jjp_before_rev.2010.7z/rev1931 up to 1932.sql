/* 20090705 npc 修正速度資料*/
Update npc Set atkspeed = '1720' Where npcid = '45326';/* 黑暗棲林者 */
Update npc Set atk_magic_speed = '2200' Where npcid = '45326';
Update npc Set sub_magic_speed = '2200' Where npcid = '45326';
Update npc Set atk_magic_speed = '0' Where npcid = '45347';/* 黑暗棲林者 */
Update npc Set sub_magic_speed = '2200' Where npcid = '45347';