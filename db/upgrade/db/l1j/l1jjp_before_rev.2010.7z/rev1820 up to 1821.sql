/* 20090525 rev1821 etcitem 道具變動 */
Update etcitem Set item_type = 'treasure_box' Where item_id = 40696 ;
Update etcitem Set 	invgfx = '957' Where item_id = 40696 ;
Update etcitem Set 	invgfx = '2054' Where item_id = 40697 ;