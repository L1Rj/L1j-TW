/* 20090626 mobgroup 變更資料 */
Update mobgroup Set note  = 'ブラックナイト -捜索隊-(2)' Where id  = '1';
Update mobgroup Set minion1_count  = '1' Where id  = '1';
Update mobgroup Set note  = 'ファイアーエッグ(2)' Where id  = '9';
Update mobgroup Set minion1_count  = '1' Where id  = '9';
Update mobgroup Set note  = 'ブラック ナイト(2)' Where id  = '50';
Update mobgroup Set minion1_count  = '1' Where id  = '50';