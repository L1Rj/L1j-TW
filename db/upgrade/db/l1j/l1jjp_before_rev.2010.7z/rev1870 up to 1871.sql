/* 20090617 rev1871  修改部份NPC資料 */
Update npc Set sub_magic_speed  = '1400' Where npcid  = '45955';
Update npc Set sub_magic_speed  = '1600' Where npcid  = '45956';
Update npc Set sub_magic_speed  = '1520' Where npcid  = '45957';
Update npc Set sub_magic_speed  = '1560' Where npcid  = '45958';
Update npc Set sub_magic_speed  = '1680' Where npcid  = '45959';
Update npc Set atk_magic_speed  = '960' Where npcid  = '46060';
Update npc Set sub_magic_speed  = '960' Where npcid  = '46060';
Update npc Set atk_magic_speed  = '1000' Where npcid  = '46061';
Update npc Set sub_magic_speed  = '1000' Where npcid  = '46061';
Update npc Set sub_magic_speed  = '1120' Where npcid  = '46065';
Update npc Set sub_magic_speed  = '1360' Where npcid  = '46067';
Update npc Set sub_magic_speed  = '1120' Where npcid  = '81236';