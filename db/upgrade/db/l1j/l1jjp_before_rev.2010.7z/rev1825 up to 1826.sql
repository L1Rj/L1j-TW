/* 20090525 rev1826 etcitem 資料變動 */
Update etcitem Set grdgfx = '6549' Where item_id = 49252 ;