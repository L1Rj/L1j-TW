/* 20090825 npc 修改資料 */

Update npc Set IsTU = '1' Where npcid = '45527';
Update npc Set IsTU = '1' Where npcid = '46009';
Update npc Set IsTU = '1' Where npcid = '46012';