/* 2009062 rev1892 修正四屬性卷軸資料 */
Update etcitem Set grdgfx = '6938' Where item_id = '41429';
Update etcitem Set grdgfx = '6935' Where item_id = '41430';
Update etcitem Set grdgfx = '6933' Where item_id = '41431';
Update etcitem Set grdgfx = '6936' Where item_id = '41432';

delete from etcitem where item_id = '49144' ;
delete from etcitem where item_id = '49145' ;
delete from etcitem where item_id = '49146' ;
delete from etcitem where item_id = '49147' ;