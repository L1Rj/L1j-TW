/* 20090618 rev1880  修正 海賊島 NPC agro資料 */
Update npc Set agro = '0' Where npcid = '45139';/* 狂野之毒 */
Update npc Set agro = '0' Where npcid = '45158';/* 狂暴蜥蜴人 */
Update npc Set agro = '0' Where npcid = '45163';/* 狂野毒牙 */
Update npc Set agro = '0' Where npcid = '45197';/* 狂野之魔 */
Update npc Set agro = '0' Where npcid = '45217';/* 高等蜥蜴人 */
Update npc Set agro = '0' Where npcid = '45239';/* 藍尾蜥蜴 */
Update npc Set agro = '0' Where npcid = '45249';/* 奇異鸚鵡 */
Update npc Set agro = '0' Where npcid = '45251';/* 重裝蜥蜴人 */