/* 20090720 command 新增資料 */
INSERT INTO `commands` VALUES
('tile', 200, 'L1Tile');