/* 20090628 weapon 修正鎖鏈劍距離資料*/

Update weapon Set range  = '2' Where item_id = '272';
Update weapon Set range  = '2' Where item_id = '273';