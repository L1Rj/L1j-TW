/* 20090630 spawnlist 修正資料*/
Update spawnlist Set count  = '25' Where id = '100002';
Update spawnlist Set count  = '35' Where id = '100003';
Update spawnlist Set count  = '30' Where id = '100004';
Update spawnlist Set count  = '2' Where id = '100005';
Update spawnlist Set count  = '1' Where id = '100006';
Update spawnlist Set group_id  = '0' Where id = '100006';
