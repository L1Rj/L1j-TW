/* 20090629 skills 修正資料*/

Update skills Set probability_dice  = '26' Where skill_id = '183';/* 護衛毀滅 */
Update skills Set type  = '1' Where skill_id = '183';
Update skills Set ranged  = '3' Where skill_id = '183';
Update skills Set probability_dice  = '26' Where skill_id = '188';/* 恐懼無助 */
Update skills Set type  = '1' Where skill_id = '188';
Update skills Set probability_dice  = '26' Where skill_id = '193';/* 驚悚死神 */
Update skills Set type  = '1' Where skill_id = '193';