/* 20090825 spr_action 修改新增資料 */

Update spr_action Set framecount = '275' Where spr_id = '123' And act_id = '0';
Update spr_action Set framecount = '275' Where spr_id = '129' And act_id = '0';
Update spr_action Set framecount = '148' Where spr_id = '149' And act_id = '3';
Update spr_action Set framecount = '128' Where spr_id = '244' And act_id = '0';
Update spr_action Set framecount = '232' Where spr_id = '1016' And act_id = '3';
Update spr_action Set framecount = '236' Where spr_id = '1018' And act_id = '3';
Update spr_action Set framecount = '168' Where spr_id = '1755' And act_id = '3';
Update spr_action Set framecount = '148' Where spr_id = '2510' And act_id = '3';
Update spr_action Set framecount = '100' Where spr_id = '3756' And act_id = '0';
Update spr_action Set framecount = '100' Where spr_id = '3743' And act_id = '0';
Update spr_action Set framecount = '279' Where spr_id = '4728' And act_id = '0';
Update spr_action Set framecount = '12' Where spr_id = '6284' And act_id = '0';
Update spr_action Set framecount = '148' Where spr_id = '7138' And act_id = '3';
Update spr_action Set framecount = '148' Where spr_id = '6686' And act_id = '3';
Update spr_action Set framecount = '148' Where spr_id = '6687' And act_id = '3';
Update spr_action Set framecount = '132' Where spr_id = '6694' And act_id = '28';
Update spr_action Set framecount = '132' Where spr_id = '6692' And act_id = '28';
Update spr_action Set framecount = '148' Where spr_id = '6689' And act_id = '3';
Update spr_action Set framecount = '148' Where spr_id = '6688' And act_id = '3';
Update spr_action Set framecount = '148' Where spr_id = '6687' And act_id = '3';

INSERT INTO `spr_action` VALUES
(7183, 0, 0, 24);