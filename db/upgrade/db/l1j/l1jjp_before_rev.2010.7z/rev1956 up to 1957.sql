/* 20090723 npc 修正 */
Update npc Set light_size = '10' Where npcid  = '45273';
Update npc Set light_size = '4' Where npcid  = '45892';
Update npc Set light_size = '4' Where npcid  = '45893';
Update npc Set light_size = '4' Where npcid  = '45895';
Update npc Set light_size = '4' Where npcid  = '45900';
Update npc Set light_size = '4' Where npcid  = '45905';
Update npc Set light_size = '4' Where npcid  = '45908';
Update npc Set light_size = '4' Where npcid  = '45909';
Update npc Set light_size = '10' Where npcid  = '45978';