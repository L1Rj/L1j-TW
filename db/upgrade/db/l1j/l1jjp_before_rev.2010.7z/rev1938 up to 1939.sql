/* 20090707 weapon 修正資料 */
Update weapon Set add_con  = '0' Where item_id = '265';
Update weapon Set add_dex  = '1' Where item_id = '265';