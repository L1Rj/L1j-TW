/* 20090704 weapon 修正資料*/
Update weapon Set canbedmg   = '0' Where item_id = '270';
Update weapon Set canbedmg   = '0' Where item_id = '271';