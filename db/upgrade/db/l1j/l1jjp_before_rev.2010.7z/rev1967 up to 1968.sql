/* 20090729 etcitem 修正資料 */

Update etcitem Set item_id = '49281' Where item_id = '90001';
Update etcitem Set item_id = '49282' Where item_id = '90007';
Update etcitem Set item_id = '49283' Where item_id = '90008';
Update etcitem Set item_id = '49284' Where item_id = '90011';
Update etcitem Set item_id = '49285' Where item_id = '90013';
Update etcitem Set item_id = '49286' Where item_id = '90016';