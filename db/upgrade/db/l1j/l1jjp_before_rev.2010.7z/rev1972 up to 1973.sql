/* 20090803 command 新增資料 */
INSERT INTO `commands` VALUES
('findinvis', 200, 'L1FindInvis');