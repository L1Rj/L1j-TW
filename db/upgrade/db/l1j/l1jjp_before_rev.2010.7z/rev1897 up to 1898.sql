/* 20090623 rev1898 修正不死系NPC資料 */
Update npc Set undead = '5' Where npcid = '45024';
Update npc Set undead = '5' Where npcid = '45037';
Update npc Set undead = '5' Where npcid = '45093';
Update npc Set undead = '5' Where npcid = '45094';
Update npc Set undead = '5' Where npcid = '45173';
Update npc Set undead = '5' Where npcid = '45355';
Update npc Set undead = '5' Where npcid = '45389';
Update npc Set undead = '5' Where npcid = '45485';
Update npc Set undead = '5' Where npcid = '45763';
Update npc Set undead = '5' Where npcid = '45769';
Update npc Set undead = '5' Where npcid = '45803';
Update npc Set undead = '5' Where npcid = '45808';
Update npc Set undead = '5' Where npcid = '45820';
Update npc Set undead = '5' Where npcid = '45824';
Update npc Set undead = '5' Where npcid = '46036';
Update npc Set undead = '5' Where npcid = '46126';
Update npc Set undead = '5' Where npcid = '81091';