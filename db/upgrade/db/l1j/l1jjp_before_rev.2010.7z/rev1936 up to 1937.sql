/* 20090706 npc 修正資料 */
Update npc Set cant_resurrect  = '1' Where npcid = '45313';
Update npc Set cant_resurrect  = '1' Where npcid = '45711';