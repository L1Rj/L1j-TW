delete from shop where npc_id = 80080 ;
insert into shop values
(80080, 41295, 2, 4600, 100, -1);