/* 20090618 rev1878  修正 skills 疼痛的歡愉 設定資料 */
Update skills Set type = '2' Where skill_id = '218';