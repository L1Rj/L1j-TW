/* 20090525 rev1827 armor 資料變動 */
Update etcitem Set name_id = '$5550' Where item_id = 21072 ;