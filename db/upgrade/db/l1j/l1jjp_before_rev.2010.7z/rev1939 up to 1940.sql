/* 20090707 skills 修正資料 */
Update skills Set probability_value = '33' Where skill_id = '133';
Update skills Set probability_value = '33' Where skill_id = '152';
Update skills Set probability_value = '33' Where skill_id = '153';
Update skills Set probability_value = '33' Where skill_id = '157';
Update skills Set probability_value = '33' Where skill_id = '161';
Update skills Set probability_value = '33' Where skill_id = '167';
Update skills Set probability_value = '33' Where skill_id = '173';
Update skills Set probability_value = '33' Where skill_id = '174';