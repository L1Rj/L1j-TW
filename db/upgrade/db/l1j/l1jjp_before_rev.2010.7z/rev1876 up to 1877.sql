/* 20090618 rev1877  修正 skills 洞察 設定資料 */
Update skills Set type = '2' Where skill_id = '216';